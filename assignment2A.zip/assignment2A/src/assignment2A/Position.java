/**
 * Project: assignment2A
 * File: Position.java
 * Date: 2015年11月23日
 * Time: 上午11:12:19
 */

package assignment2A;

/**
 * @author Lize Wu A00917368
 *
 */
public class Position {
	public int[] p = new int[2];

	/**
	 * @param p
	 */
	public Position(int pi, int pj) {
		super();
		p[0] = pi;
		p[1] = pj;
	}

	/**
	 * @return the p
	 */
	public int[] getP() {
		return p;
	}
	
	

}
